import MassGap.WilsonLattice
import MassGap.WilsonAction
import MassGap.SUN

/-!
# MassGap.WilsonReal — a concrete SU(2) Wilson system with a genuine symmetry (dynamical face, brick 2b)

Non-vacuousness for the `WilsonLattice` framework: a real `SU(2)` gauge theory with **two plaquettes**,
each a genuine four-link ordered Wilson loop `U₀ U₁ U₂⁻¹ U₃⁻¹`, the **real Wilson action density**
(`WilsonAction.wilsonDensity`), and a `ℤ/2` symmetry that **swaps the two plaquettes** (relabelling the
eight links by the block map `i ↦ i+4`). The boundary-word compatibility `hbd2` is a finite computation
(`decide`), and `sysReal_invariant` is the Euclidean/permutation invariance of the genuine Wilson Gibbs
correlation under that swap — derived from Haar-invariance, on the real action. Foundational footprint.

Build: `lake build MassGap.WilsonReal`.
-/

namespace MassGap.WilsonReal

open MassGap.LatticeGauge MassGap.WilsonLattice MassGap.WilsonAction MassGap.CompactGauge MeasureTheory

/-- `SU(2)`. -/
abbrev G2 : Type := MassGap.SUN.SU 2

/-- Two plaquettes over eight links, each a four-link loop `U₀U₁U₂⁻¹U₃⁻¹`. -/
def bd2 (p : Fin 2) : List (Fin 8 × Bool) :=
  if p = 0 then [(0, true), (1, true), (2, false), (3, false)]
  else [(4, true), (5, true), (6, false), (7, false)]

/-- Link relabelling `i ↦ i + 4` on `Fin 8` — the block swap exchanging the two plaquettes' links. -/
def σL2 : Equiv.Perm (Fin 8) := Equiv.addLeft (4 : Fin 8)

/-- Plaquette swap on `Fin 2`. -/
def σP2 : Equiv.Perm (Fin 2) := Equiv.swap 0 1

/-- The boundary words map compatibly under the swap — a finite check. -/
theorem hbd2 : ∀ p, bd2 (σP2 p) = (bd2 p).map (fun lo => (σL2 lo.1, lo.2)) := by decide

/-- The concrete two-plaquette `SU(2)` Wilson system (genuine ordered-loop holonomy, real action). -/
noncomputable def sysReal : System G2 := wilsonSystem bd2 wilsonDensity

/-- The `ℤ/2` plaquette-swap symmetry of the Wilson system. -/
noncomputable def symReal : Symmetry sysReal := wilsonSymmetry bd2 wilsonDensity σL2 σP2 hbd2

/-- **Invariance of the real `SU(2)` Wilson correlation under the plaquette swap.** For the canonical
probability Haar measure (or any left-invariant probability measure), the Gibbs expectation is invariant
under transporting the observable by the swap — derived from Haar-invariance, on the genuine Wilson
action. -/
theorem sysReal_invariant (μ : Measure G2) [IsProbabilityMeasure μ] (β : ℝ)
    (O : sysReal.Config → ℝ) :
    sysReal.expect μ β (fun U => O (Symmetry.reindex symReal.onLink U)) = sysReal.expect μ β O :=
  wilson_expect_invariant bd2 wilsonDensity σL2 σP2 hbd2 μ β O

/-- **The Wilson action density is invariant under a global gauge transformation.** Conjugating every
link by a fixed `g ∈ SU(N)` conjugates the plaquette holonomy (`wilsonHol_conj`), and `wilsonDensity`
is conjugation-invariant (`wilsonDensity_conj`) — so the plaquette Wilson action is gauge-invariant.
The algebraic content of gauge invariance, on the genuine ordered-loop holonomy; general `N`. -/
theorem wilsonAction_gauge_invariant {N : ℕ} {Lk Pq : Type}
    (bd : Pq → List (Lk × Bool)) (g : MassGap.SUN.SU N) (p : Pq)
    (U : Lk → MassGap.SUN.SU N) :
    wilsonDensity (wilsonHol bd p (fun l => g * U l * g⁻¹))
      = wilsonDensity (wilsonHol bd p U) := by
  rw [wilsonHol_conj]
  exact wilsonDensity_conj g (wilsonHol bd p U)

/-- The Wilson action is invariant under a global gauge transformation (each plaquette term, from
`wilsonAction_gauge_invariant`). -/
theorem sysReal_action_gauge (g : G2) (U : sysReal.Config) :
    sysReal.action (confConj G2 g U) = sysReal.action U :=
  Finset.sum_congr rfl (fun p _ => wilsonAction_gauge_invariant bd2 g p U)

/-- The Boltzmann weight is invariant under a global gauge transformation. -/
theorem sysReal_boltz_gauge (g : G2) (β : ℝ) (U : sysReal.Config) :
    sysReal.boltz β (confConj G2 g U) = sysReal.boltz β U := by
  unfold System.boltz; rw [sysReal_action_gauge]

/-- **Gauge invariance of the real `SU(2)` Wilson correlation.** For the canonical probability Haar
measure, the Gibbs expectation is invariant under a global gauge transformation `U ↦ gUg⁻¹`: the
conjugation preserves the Haar measure (`confConjEquiv_measurePreserving`, from unimodularity) and the
Wilson action (`sysReal_boltz_gauge`), so `⟨O∘conj⟩ = ⟨O⟩` by the general mechanism
`expect_invariant_of_mp`. The defining symmetry of a gauge theory, on the genuine ordered-loop Wilson
action. -/
theorem sysReal_gauge_invariant (g : G2) (β : ℝ) (O : sysReal.Config → ℝ) :
    sysReal.expect (probHaar G2) β (fun U => O (confConj G2 g U))
      = sysReal.expect (probHaar G2) β O :=
  System.expect_invariant_of_mp sysReal (probHaar G2) β O (confConjEquiv G2 g)
    (confConjEquiv_measurePreserving G2 g) (fun U => sysReal_boltz_gauge g β U)

#print axioms hbd2
#print axioms sysReal_invariant
#print axioms wilsonAction_gauge_invariant
#print axioms sysReal_gauge_invariant

end MassGap.WilsonReal
